# Nemotron Fine-tuned Model Comparison

| Model | Rows | Avg WER % | Avg CER % | Entity Score % |
|---|---:|---:|---:|---:|
| base | 15 | 38.51 | 23.92 | 0.00 |
| v1_lr3e6_ep2 ⭐ Best | 15 | 35.18 | 22.57 | 0.00 |
| v2_lr2e6_ep3 | 15 | 35.18 | 22.57 | 0.00 |
| v3_lr1e6_ep3 | 15 | 37.62 | 23.51 | 0.00 |

## Recommendation

Best model by WER is **v1_lr3e6_ep2** with WER **35.18%** and CER **22.57%**.