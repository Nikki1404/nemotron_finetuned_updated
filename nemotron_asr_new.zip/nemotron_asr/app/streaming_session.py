import time
from app.vad import AdaptiveEnergyVAD


class StreamingSession:
    """
    Orchestrates VAD + ASR engine for a single WebSocket connection.

    Responsibilities:
    - Split incoming PCM16 bytes into VAD frames
    - Detect speech onset / end using AdaptiveEnergyVAD
    - Forward speech audio to the ASR engine session
    - Collect partial results during speech
    - Trigger finalize() on silence after speech
    - Return typed events: ("partial", text, ttfb_ms) or ("final", text, ttfb_ms)
    """

    def __init__(self, engine, cfg):
        self.engine = engine
        self.cfg = cfg

        self.vad = AdaptiveEnergyVAD(
            cfg.sample_rate,
            cfg.vad_frame_ms,
            cfg.vad_start_margin,
            cfg.vad_min_noise_rms,
            cfg.pre_speech_ms,
        )

        self.session = engine.new_session(max_buffer_ms=cfg.max_utt_ms)

        self.frame_bytes = int(cfg.sample_rate * cfg.vad_frame_ms / 1000) * 2
        self.raw_buf = bytearray()

        self.utt_started = False
        self.utt_audio_ms = 0
        self.t_utt_start = None
        self.t_first_partial = None
        self.silence_ms = 0

    def process_chunk(self, pcm: bytes) -> list:
        """
        Process one incoming PCM16 chunk (any size).
        Returns a list of events: [(type, text, ttfb_ms), ...]
        Types: "partial" | "final"
        """
        events = []

        self.raw_buf.extend(pcm)

        while len(self.raw_buf) >= self.frame_bytes:
            frame = bytes(self.raw_buf[: self.frame_bytes])
            del self.raw_buf[: self.frame_bytes]

            is_speech, pre = self.vad.push_frame(frame)

            self.silence_ms = (
                0 if is_speech else self.silence_ms + self.cfg.vad_frame_ms
            )

            # ── Speech onset ───────────────────────────────────────────────
            if pre and not self.utt_started:
                self.utt_started = True
                self.utt_audio_ms = 0
                self.t_utt_start = time.time()
                self.t_first_partial = None
                self.session.accept_pcm16(pre)

            if not self.utt_started:
                continue

            # ── Feed current frame ─────────────────────────────────────────
            self.session.accept_pcm16(frame)
            self.utt_audio_ms += self.cfg.vad_frame_ms

            # ── Emit partial transcript ────────────────────────────────────
            if self.engine.caps.partials:
                text = self.session.step_if_ready()
                if text:
                    if self.t_first_partial is None:
                        self.t_first_partial = time.time()
                    ttfb_ms = int(
                        (self.t_first_partial - self.t_utt_start) * 1000
                    )
                    events.append(("partial", text, ttfb_ms))

            # ── End-of-utterance detection ─────────────────────────────────
            if (
                not is_speech
                and self.utt_audio_ms >= self.engine.min_utt_ms
                and self.silence_ms >= self.engine.end_silence_ms
            ):
                final = self.session.finalize(self.engine.finalize_pad_ms)

                if final:
                    ttfb_ms = (
                        int((self.t_first_partial - self.t_utt_start) * 1000)
                        if self.t_first_partial
                        else None
                    )
                    events.append(("final", final, ttfb_ms))

                self.reset()

        return events

    def reset(self):
        """Reset utterance state (called after each finalized utterance)."""
        self.vad.reset()
        self.utt_started = False
        self.utt_audio_ms = 0
        self.silence_ms = 0
