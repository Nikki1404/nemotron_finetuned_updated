from dataclasses import dataclass, replace
import os


@dataclass(frozen=True)
class Config:
    # ── Core ASR selection ──────────────────────────────────────────────────
    asr_backend: str = os.getenv("ASR_BACKEND", "nemotron")
    model_name: str = os.getenv("MODEL_NAME", "")
    device: str = os.getenv("DEVICE", "cuda")

    # ── Language (new for nemotron-3.5 multilingual) ────────────────────────
    # "auto"  = model detects language from audio
    # "en-US" = English (US)       "en-GB" = English (UK)
    # "es-US" = Spanish (US)       "es-ES" = Spanish (Spain)
    # Full list: en-US, en-GB, es-US, es-ES, fr-FR, fr-CA, de-DE, it-IT,
    #            pt-BR, pt-PT, ru-RU, nl-NL, pl-PL, cs-CZ, ar-AR, hi-IN,
    #            ja-JP, ko-KR, vi-VN, tr-TR, nb-NO, he-IL, da-DK, sv-SE,
    #            bg-BG, fi-FI, hr-HR, sk-SK, uk-UA, zh-CN, el-GR, hu-HU,
    #            ro-RO, et-EE, lt-LT, lv-LV, mt-MT, sl-SI, th-TH, nn-NO
    asr_language: str = os.getenv("ASR_LANGUAGE", "auto")

    # ── Common audio ────────────────────────────────────────────────────────
    sample_rate: int = int(os.getenv("SAMPLE_RATE", "16000"))

    # ── Common VAD ──────────────────────────────────────────────────────────
    vad_frame_ms: int = int(os.getenv("VAD_FRAME_MS", "20"))
    vad_start_margin: float = float(os.getenv("VAD_START_MARGIN", "2.5"))
    vad_min_noise_rms: float = float(os.getenv("VAD_MIN_NOISE_RMS", "0.003"))
    pre_speech_ms: int = int(os.getenv("PRE_SPEECH_MS", "300"))

    # ── Global safety constraint ────────────────────────────────────────────
    max_utt_ms: int = int(os.getenv("MAX_UTT_MS", "30000"))

    log_level: str = os.getenv("LOG_LEVEL", "INFO")


# ── Model map ───────────────────────────────────────────────────────────────
# Single "nemotron" backend covers both en + es via language prompt.
# For concurrent multi-language with isolated engine state, add separate keys:
#   "nemotron-en": "nvidia/nemotron-3.5-asr-streaming-0.6b"
#   "nemotron-es": "nvidia/nemotron-3.5-asr-streaming-0.6b"
MODEL_MAP = {
    "nemotron": "nvidia/nemotron-3.5-asr-streaming-0.6b",
}

# If you pre-download the model to disk (done in Dockerfile), override to:
#   "nemotron": "/srv/nemotron-3.5-asr-streaming-0.6b.nemo"
# LOCAL_MODEL_MAP = {
#     "nemotron": "/srv/nemotron-3.5-asr-streaming-0.6b.nemo",
# }


def load_config() -> Config:
    cfg = Config()

    if not cfg.model_name:
        cfg = replace(cfg, model_name=MODEL_MAP.get(cfg.asr_backend, ""))

    print(
        f"DEBUG: Startup cfg.model_name='{cfg.model_name}' "
        f"cfg.asr_backend='{cfg.asr_backend}' "
        f"cfg.asr_language='{cfg.asr_language}'"
    )

    return cfg
