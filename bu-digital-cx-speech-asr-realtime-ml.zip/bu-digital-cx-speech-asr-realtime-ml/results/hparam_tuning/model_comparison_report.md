# Nemotron Fine-tuned Model Comparison

| Model | Rows | Avg WER % | Avg CER % | Entity Score % |
|---|---:|---:|---:|---:|
| base | 7 | 34.93 | 21.46 | 0.00 |
| v1_lr3e6_ep2 ⭐ Best | 7 | 17.06 | 13.67 | 0.00 |
| v2_lr2e6_ep3 | 7 | 17.06 | 13.67 | 0.00 |
| v3_lr1e6_ep3 | 7 | 26.11 | 17.69 | 0.00 |

## Recommendation

Best model by WER is **v1_lr3e6_ep2** with WER **17.06%** and CER **13.67%**.