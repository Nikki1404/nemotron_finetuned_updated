#!/usr/bin/env python3
"""
06_benchmark_latency.py

Measures the latency metrics that actually matter for your production
websocket server, using YOUR real app/asr_engines/nemotron_asr.py classes
(NemotronStreamingASR + StreamingSession) — not a reimplementation — so
numbers here are what you'd actually see behind the FastAPI endpoint.

Reports, for baseline vs fine-tuned model:
  - TTFT (time to first partial transcript), ms
  - Per-chunk inference latency (mean / p50 / p95), ms
  - RTF (real-time factor): total_infer_time / audio_duration
    (RTF < 1.0 = faster than real-time, required for live streaming)
  - End-to-end finalize latency (ms)

Run this on the SAME GPU class you'll deploy on — latency numbers are
hardware-dependent and only meaningful relative to your deployment target.

Usage:
  python 06_benchmark_latency.py \
      --baseline_model nvidia/nemotron-3.5-asr-streaming-0.6b \
      --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
      --val_manifest ../manifests/val_manifest.json \
      --context_right 1
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import soundfile as sf

# project layout: <project_root>/finetune/scripts/06_benchmark_latency.py
# parents[0]=scripts  parents[1]=finetune  parents[2]=<project_root> (contains app/)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def benchmark_model(model_name_or_path, entries, context_right, device):
    from app.asr_engines.nemotron_asr import NemotronStreamingASR

    eng = NemotronStreamingASR(
        model_name=model_name_or_path,
        device=device,
        sample_rate=16000,
        language="en-US",
    )
    import os
    os.environ["CONTEXT_RIGHT"] = str(context_right)
    load_sec = eng.load()
    print(f"Loaded {model_name_or_path} in {load_sec:.2f}s "
          f"(chunk={eng.chunk_samples} samples = {1000*eng.chunk_samples/eng.sr:.0f}ms)")

    chunk_latencies_ms = []
    ttft_ms = []
    finalize_latencies_ms = []
    rtf_num, rtf_den = 0.0, 0.0

    for e in entries:
        x, sr = sf.read(e["audio_filepath"], always_2d=False)
        if x.ndim > 1:
            x = x.mean(axis=1)
        x = x.astype(np.float32)
        dur_sec = len(x) / sr

        sess = eng.new_session(max_buffer_ms=30000)
        pcm16 = (np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes()
        step_bytes = eng.chunk_samples * 2

        first_partial_t = None
        t_start = time.perf_counter()
        infer_total = 0.0

        for i in range(0, len(pcm16), step_bytes):
            sess.accept_pcm16(pcm16[i:i + step_bytes])
            t0 = time.perf_counter()
            text = sess.step_if_ready()
            t1 = time.perf_counter()
            step_ms = (t1 - t0) * 1000
            if step_ms > 0:
                chunk_latencies_ms.append(step_ms)
                infer_total += (t1 - t0)
            if text and first_partial_t is None:
                first_partial_t = t1

        t_fin0 = time.perf_counter()
        _ = sess.finalize(pad_ms=500)
        t_fin1 = time.perf_counter()
        finalize_latencies_ms.append((t_fin1 - t_fin0) * 1000)

        if first_partial_t is not None:
            ttft_ms.append((first_partial_t - t_start) * 1000)

        rtf_num += infer_total
        rtf_den += dur_sec

    def pct(arr, p):
        return float(np.percentile(arr, p)) if arr else float("nan")

    result = {
        "model": model_name_or_path,
        "context_right": context_right,
        "chunk_latency_ms_mean": float(np.mean(chunk_latencies_ms)) if chunk_latencies_ms else float("nan"),
        "chunk_latency_ms_p50": pct(chunk_latencies_ms, 50),
        "chunk_latency_ms_p95": pct(chunk_latencies_ms, 95),
        "ttft_ms_mean": float(np.mean(ttft_ms)) if ttft_ms else float("nan"),
        "ttft_ms_p95": pct(ttft_ms, 95),
        "finalize_ms_mean": float(np.mean(finalize_latencies_ms)) if finalize_latencies_ms else float("nan"),
        "rtf": rtf_num / rtf_den if rtf_den > 0 else float("nan"),
    }
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline_model", default="nvidia/nemotron-3.5-asr-streaming-0.6b")
    ap.add_argument("--finetuned_model", required=True)
    ap.add_argument("--val_manifest", required=True)
    ap.add_argument("--context_right", type=int, default=1,
                     help="Must match production CONTEXT_RIGHT env for numbers to be meaningful")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--out_json", default="../checkpoints/latency_results.json")
    args = ap.parse_args()

    entries = [json.loads(l) for l in open(args.val_manifest)]

    results = {}
    for tag, model_path in [("baseline", args.baseline_model), ("finetuned", args.finetuned_model)]:
        print(f"\n===== Benchmarking {tag}: {model_path} =====")
        results[tag] = benchmark_model(model_path, entries, args.context_right, args.device)

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_json, "w") as f:
        json.dump(results, f, indent=2)

    print("\n\n=========== LATENCY SUMMARY ===========")
    print(f"{'metric':<22}{'baseline':>14}{'finetuned':>14}")
    keys = ["ttft_ms_mean", "ttft_ms_p95", "chunk_latency_ms_mean",
            "chunk_latency_ms_p95", "finalize_ms_mean", "rtf"]
    for k in keys:
        b, f_ = results["baseline"][k], results["finetuned"][k]
        print(f"{k:<22}{b:>14.2f}{f_:>14.2f}")
    print(f"\nRTF < 1.0 required for real-time streaming. "
          f"finetuned rtf={results['finetuned']['rtf']:.3f}")
    print(f"Full results -> {args.out_json}")


if __name__ == "__main__":
    main()
