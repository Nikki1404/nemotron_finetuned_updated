#!/usr/bin/env python3
"""
05_evaluate.py

Computes WER + CER for baseline (pretrained) vs fine-tuned model, across
THREE conditions built from your val manifest, so "less WER/CER, more
robust in noisy/telephony" is actually measured, not assumed:

  clean      - val clips as-is
  telephony  - val clips run through the same band-limit/mu-law sim used
               in 02_augment_data.py (proxy for real PSTN calls)
  noisy      - val clips with additive noise at SNR ~5dB (harder than the
               training augmentation range, to check generalization)

Uses the model's OFFLINE transcribe() for a clean accuracy signal, and
also runs each val clip through the actual StreamingSession (the same
code path app/streaming_session.py drives in production) to report
streaming WER separately — these can diverge, and streaming WER is what
users actually experience.

Usage:
  python 05_evaluate.py \
      --baseline_model nvidia/nemotron-3.5-asr-streaming-0.6b \
      --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
      --val_manifest ../manifests/val_manifest.json
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import jiwer

# project layout: <project_root>/finetune/scripts/05_evaluate.py
# parents[0]=scripts  parents[1]=finetune  parents[2]=<project_root> (contains app/)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

TRANSFORM = jiwer.Compose([
    jiwer.ToLowerCase(),
    jiwer.RemoveMultipleSpaces(),
    jiwer.Strip(),
    jiwer.RemovePunctuation(),
    jiwer.ReduceToListOfListOfWords(),
])
CER_TRANSFORM = jiwer.Compose([
    jiwer.ToLowerCase(),
    jiwer.RemoveMultipleSpaces(),
    jiwer.Strip(),
    jiwer.RemovePunctuation(),
    jiwer.ReduceToListOfListOfChars(),
])


def make_telephony(x, sr):
    # inline reimplementation (avoids importing the numbered 02_augment_data.py
    # module by filename): same logic as 02_augment_data.py's band_limit_telephony
    import resampy
    x8 = resampy.resample(x, sr, 8000)
    n = len(x8)
    spec = np.fft.rfft(x8)
    freqs = np.fft.rfftfreq(n, d=1 / 8000)
    mask = (freqs >= 300) & (freqs <= 3400)
    x8 = np.fft.irfft(spec * mask, n=n).astype(np.float32)
    mu = 255.0
    x8 = np.clip(x8, -1.0, 1.0)
    comp = np.sign(x8) * np.log1p(mu * np.abs(x8)) / np.log1p(mu)
    q = np.round(comp * 127) / 127
    x8 = np.sign(q) * (1.0 / mu) * (np.expm1(np.abs(q) * np.log1p(mu)))
    out = resampy.resample(x8.astype(np.float32), 8000, sr)
    out = out[:len(x)] if len(out) >= len(x) else np.pad(out, (0, len(x) - len(out)))
    return out.astype(np.float32)


def make_noisy(x, sr, snr_db=5.0):
    np.random.seed(0)
    white = np.random.randn(len(x)).astype(np.float32)
    spec = np.fft.rfft(white)
    freqs = np.fft.rfftfreq(len(x), d=1 / sr)
    spec = spec / np.sqrt(np.maximum(freqs, 1.0))
    pink = np.fft.irfft(spec, n=len(x)).astype(np.float32)
    noise = pink / (np.std(pink) + 1e-8) * 0.05
    sig_power = np.mean(x ** 2) + 1e-12
    noise_power = np.mean(noise ** 2) + 1e-12
    noise = noise * np.sqrt((sig_power / (10 ** (snr_db / 10))) / noise_power)
    return np.clip(x + noise, -1.0, 1.0).astype(np.float32)


def offline_transcribe(model, audio_paths):
    hyps = model.transcribe(audio_paths, batch_size=4)
    return [h.text if hasattr(h, "text") else str(h) for h in hyps]


def streaming_transcribe(engine_cls, model, audio_f32_list, sr):
    """Drive the same StreamingSession path production uses, chunked in
    ~80ms increments like real mic/telephony audio would arrive."""
    from app.asr_engines.nemotron_asr import NemotronStreamingASR

    eng = NemotronStreamingASR.__new__(NemotronStreamingASR)
    eng.model = model
    eng.sr = sr
    eng.device = "cuda" if next(model.parameters()).is_cuda else "cpu"
    scfg = model.encoder.streaming_cfg
    eng.shift_frames = scfg.shift_size[1] if isinstance(scfg.shift_size, (list, tuple)) else scfg.shift_size
    pre_cache = scfg.pre_encode_cache_size
    eng.pre_cache_frames = pre_cache[1] if isinstance(pre_cache, (list, tuple)) else pre_cache
    eng.drop_extra = int(getattr(scfg, "drop_extra_pre_encoded", 0))
    eng._frame_stride_sec = float(model.cfg.preprocessor.get("window_stride", 0.01))
    eng.hop_samples = int(eng._frame_stride_sec * sr)

    results = []
    for audio in audio_f32_list:
        sess = eng.new_session(max_buffer_ms=30000)
        chunk = eng.chunk_samples
        pcm16 = (np.clip(audio, -1, 1) * 32767).astype(np.int16).tobytes()
        step_bytes = chunk * 2
        for i in range(0, len(pcm16), step_bytes):
            sess.accept_pcm16(pcm16[i:i + step_bytes])
            sess.step_if_ready()
        final = sess.finalize(pad_ms=500)
        results.append(final)
    return results


def score(refs, hyps):
    refs_ = [r if r.strip() else " " for r in refs]
    hyps_ = [h if h.strip() else " " for h in hyps]
    wer = jiwer.wer(refs_, hyps_, truth_transform=TRANSFORM, hypothesis_transform=TRANSFORM)
    cer = jiwer.wer(refs_, hyps_, truth_transform=CER_TRANSFORM, hypothesis_transform=CER_TRANSFORM)
    return wer, cer


def run_condition(name, model, entries, make_fn=None):
    import tempfile
    paths, refs, audios, srs = [], [], [], []
    tmpdir = Path(tempfile.mkdtemp())
    for e in entries:
        x, sr = sf.read(e["audio_filepath"], always_2d=False)
        if x.ndim > 1:
            x = x.mean(axis=1)
        x = x.astype(np.float32)
        if make_fn:
            x = make_fn(x, sr)
        p = tmpdir / Path(e["audio_filepath"]).name
        sf.write(str(p), x, sr, subtype="PCM_16")
        paths.append(str(p))
        refs.append(e["text"])
        audios.append(x)
        srs.append(sr)

    hyps_offline = offline_transcribe(model, paths)
    wer_off, cer_off = score(refs, hyps_offline)

    hyps_stream = streaming_transcribe(None, model, audios, srs[0])
    wer_str, cer_str = score(refs, hyps_stream)

    print(f"\n--- {name} ---")
    print(f"  offline:   WER={wer_off:.3f}  CER={cer_off:.3f}")
    print(f"  streaming: WER={wer_str:.3f}  CER={cer_str:.3f}")
    return {
        "condition": name,
        "offline_wer": wer_off, "offline_cer": cer_off,
        "streaming_wer": wer_str, "streaming_cer": cer_str,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline_model", default="nvidia/nemotron-3.5-asr-streaming-0.6b")
    ap.add_argument("--finetuned_model", required=True)
    ap.add_argument("--val_manifest", required=True)
    ap.add_argument("--out_json", default="../checkpoints/eval_results.json")
    args = ap.parse_args()

    import nemo.collections.asr as nemo_asr

    entries = [json.loads(l) for l in open(args.val_manifest)]
    print(f"Evaluating on {len(entries)} val clips across clean/telephony/noisy...")

    conditions = [("clean", None), ("telephony", make_telephony), ("noisy", make_noisy)]

    all_results = {}
    for tag, model_path in [("baseline", args.baseline_model), ("finetuned", args.finetuned_model)]:
        print(f"\n===== {tag.upper()}: {model_path} =====")
        if model_path.endswith(".nemo"):
            model = nemo_asr.models.ASRModel.restore_from(model_path)
        else:
            model = nemo_asr.models.ASRModel.from_pretrained(model_path)
        model.encoder.set_default_att_context_size([70, 1])
        model.eval()
        if next(model.parameters(), None) is not None:
            try:
                model = model.cuda()
            except Exception:
                pass

        results = [run_condition(name, model, entries, fn) for name, fn in conditions]
        all_results[tag] = results
        del model

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_json, "w") as f:
        json.dump(all_results, f, indent=2)

    print("\n\n=========== SUMMARY (streaming WER, the production-relevant number) ===========")
    print(f"{'condition':<12}{'baseline':>12}{'finetuned':>12}{'rel. change':>14}")
    for i, (name, _) in enumerate(conditions):
        b = all_results["baseline"][i]["streaming_wer"]
        f_ = all_results["finetuned"][i]["streaming_wer"]
        rel = (f_ - b) / b * 100 if b > 0 else float("nan")
        print(f"{name:<12}{b:>12.3f}{f_:>12.3f}{rel:>13.1f}%")
    print(f"\nFull results -> {args.out_json}")


if __name__ == "__main__":
    main()
