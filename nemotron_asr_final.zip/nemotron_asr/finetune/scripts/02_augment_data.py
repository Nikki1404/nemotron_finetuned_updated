#!/usr/bin/env python3
"""
02_augment_data.py

Offline data augmentation for the TRAIN manifest only (never augment val/test —
you want to measure real generalization on clean-ish held-out data, plus we
create separate clean/noisy/telephony eval sets in 05_evaluate.py).

With only ~9 min of train audio, augmentation is doing a lot of the heavy
lifting against overfitting and for real-world robustness. Each clip is
expanded into multiple augmented variants:

  clean        - original, as-is (always kept)
  telephony    - 8kHz band-limit (300-3400Hz) + upsample back, mu-law
                 companding, to emulate PSTN/telephony codec artifacts
  noisy        - additive noise (white / babble-like / office hum) at
                 randomized SNR 0-20 dB
  telephony+noisy - both stacked (closest to real call-center audio)
  reverb       - light synthetic room reverb (far-field mic simulation)
  speed/gain   - tempo perturb (0.9x-1.1x) + gain perturb (+-6dB)

Additional online augmentation (SpecAugment, further speed perturb) is
configured separately in configs/finetune_config.yaml and applied live
during training by NeMo's AudioToCharDataset / AudioAugmentor — that's
"free" augmentation and doesn't need to be materialized to disk.

Usage:
  python 02_augment_data.py \
      --manifest ../manifests/train_manifest.json \
      --out_manifest ../manifests/train_manifest_aug.json \
      --out_dir ../data/clips_aug \
      --noise_dir ../data/noise   # optional folder of .wav noise clips
"""
import argparse
import json
import random
from pathlib import Path

import numpy as np
import soundfile as sf
import resampy


def band_limit_telephony(x: np.ndarray, sr: int) -> np.ndarray:
    """Simulate PSTN telephony channel: 8kHz sampling + 300-3400Hz bandpass
    + mu-law compand/expand, then back to original sr."""
    # downsample to 8k (this alone removes everything above 4kHz)
    x8 = resampy.resample(x, sr, 8000)

    # crude bandpass via FFT mask (300-3400 Hz), no extra scipy dependency needed
    n = len(x8)
    if n > 0:
        spec = np.fft.rfft(x8)
        freqs = np.fft.rfftfreq(n, d=1 / 8000)
        mask = (freqs >= 300) & (freqs <= 3400)
        spec = spec * mask
        x8 = np.fft.irfft(spec, n=n).astype(np.float32)

    # mu-law companding round trip (codec-like nonlinearity + quantization noise)
    mu = 255.0
    x8 = np.clip(x8, -1.0, 1.0)
    comp = np.sign(x8) * np.log1p(mu * np.abs(x8)) / np.log1p(mu)
    q = np.round(comp * 127) / 127  # 8-bit-ish quantization
    x8 = np.sign(q) * (1.0 / mu) * (np.expm1(np.abs(q) * np.log1p(mu)))

    # back to original sample rate
    out = resampy.resample(x8.astype(np.float32), 8000, sr)
    if len(out) < len(x):
        out = np.pad(out, (0, len(x) - len(out)))
    return out[:len(x)].astype(np.float32)


def add_noise(x: np.ndarray, sr: int, noise_bank: list[np.ndarray], snr_db: float) -> np.ndarray:
    if noise_bank:
        n = random.choice(noise_bank)
        if len(n) < len(x):
            reps = int(np.ceil(len(x) / len(n)))
            n = np.tile(n, reps)
        start = random.randint(0, max(0, len(n) - len(x)))
        noise = n[start:start + len(x)]
    else:
        # synthesize simple office-hum-ish noise: pink-ish + 50/60Hz hum
        t = np.arange(len(x)) / sr
        white = np.random.randn(len(x)).astype(np.float32)
        # pinkify by 1/f filtering in freq domain
        spec = np.fft.rfft(white)
        freqs = np.fft.rfftfreq(len(x), d=1 / sr)
        spec = spec / np.sqrt(np.maximum(freqs, 1.0))
        pink = np.fft.irfft(spec, n=len(x)).astype(np.float32)
        hum = 0.02 * np.sin(2 * np.pi * 60 * t).astype(np.float32)
        noise = pink / (np.std(pink) + 1e-8) * 0.05 + hum

    sig_power = np.mean(x ** 2) + 1e-12
    noise_power = np.mean(noise ** 2) + 1e-12
    target_noise_power = sig_power / (10 ** (snr_db / 10))
    noise = noise * np.sqrt(target_noise_power / noise_power)
    return (x + noise).astype(np.float32)


def light_reverb(x: np.ndarray, sr: int, decay: float = 0.35, tail_ms: int = 120) -> np.ndarray:
    """Cheap synthetic reverb via a short exponentially-decaying impulse response
    (no external RIR dataset needed) to emulate a far-field / room mic."""
    n_tail = int(sr * tail_ms / 1000)
    ir = np.exp(-np.linspace(0, 6, n_tail)).astype(np.float32)
    ir /= ir.sum()
    wet = np.convolve(x, ir)[:len(x)]
    return ((1 - decay) * x + decay * wet).astype(np.float32)


def speed_perturb(x: np.ndarray, sr: int, factor: float) -> np.ndarray:
    return resampy.resample(x, sr, int(sr / factor)).astype(np.float32)


def gain_perturb(x: np.ndarray, db: float) -> np.ndarray:
    return (x * (10 ** (db / 20))).astype(np.float32)


def load_noise_bank(noise_dir: str | None, sr: int) -> list[np.ndarray]:
    bank = []
    if noise_dir and Path(noise_dir).exists():
        for p in Path(noise_dir).glob("*.wav"):
            a, s = sf.read(str(p), always_2d=False)
            if a.ndim > 1:
                a = a.mean(axis=1)
            if s != sr:
                a = resampy.resample(a.astype(np.float32), s, sr)
            bank.append(a.astype(np.float32))
    return bank


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out_manifest", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--noise_dir", default=None,
                     help="Optional dir of real noise .wav files (office/babble/street). "
                          "If omitted, synthetic noise is used.")
    ap.add_argument("--variants_per_clip", type=int, default=5,
                     help="How many augmented variants to generate per clip, "
                          "in addition to keeping the clean original.")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    entries = [json.loads(l) for l in open(args.manifest)]
    if not entries:
        raise SystemExit(f"Empty manifest: {args.manifest}")

    # infer sr from first file
    _, sr = sf.read(entries[0]["audio_filepath"], always_2d=False)
    noise_bank = load_noise_bank(args.noise_dir, sr)
    if not noise_bank:
        print("No noise_dir provided/found -> using synthetic pink noise + hum. "
              "For best telephony/noisy real-world results, supply real recorded "
              "noise clips (call-center floor noise, street, office) via --noise_dir.")

    kinds = ["telephony", "noisy", "telephony_noisy", "reverb", "speed_gain"]

    out_entries = []
    for e in entries:
        x, esr = sf.read(e["audio_filepath"], always_2d=False)
        if x.ndim > 1:
            x = x.mean(axis=1)
        x = x.astype(np.float32)

        # always keep the clean original
        out_entries.append(e)

        chosen = random.sample(kinds, k=min(args.variants_per_clip, len(kinds)))
        stem = Path(e["audio_filepath"]).stem

        for kind in chosen:
            y = x.copy()
            if kind == "telephony":
                y = band_limit_telephony(y, esr)
            elif kind == "noisy":
                y = add_noise(y, esr, noise_bank, snr_db=random.uniform(0, 20))
            elif kind == "telephony_noisy":
                y = band_limit_telephony(y, esr)
                y = add_noise(y, esr, noise_bank, snr_db=random.uniform(3, 15))
            elif kind == "reverb":
                y = light_reverb(y, esr, decay=random.uniform(0.2, 0.45))
            elif kind == "speed_gain":
                y = speed_perturb(y, esr, factor=random.uniform(0.9, 1.1))
                y = gain_perturb(y, db=random.uniform(-6, 6))

            y = np.clip(y, -1.0, 1.0)
            out_path = out_dir / f"{stem}_{kind}.wav"
            sf.write(str(out_path), y, esr, subtype="PCM_16")
            out_entries.append({
                "audio_filepath": str(out_path.resolve()),
                "text": e["text"],
                "duration": round(len(y) / esr, 3),
            })

    with open(args.out_manifest, "w") as f:
        for e in out_entries:
            f.write(json.dumps(e) + "\n")

    total_min = sum(e["duration"] for e in out_entries) / 60
    print(f"Wrote {len(out_entries)} entries ({total_min:.1f} min) -> {args.out_manifest}")
    print(f"(clean originals: {len(entries)}, augmented variants: {len(out_entries) - len(entries)})")


if __name__ == "__main__":
    main()
