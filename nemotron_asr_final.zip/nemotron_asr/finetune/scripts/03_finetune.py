#!/usr/bin/env python3
"""
03_finetune.py

Loads the pretrained nvidia/nemotron-3.5-asr-streaming-0.6b (same model
app/asr_engines/nemotron_asr.py serves), applies partial-freezing so a tiny
dataset can't wreck its general ability, and fine-tunes on your manifests.

Run on your GPU box:
  python 03_finetune.py --config ../configs/finetune_config.yaml

Override any single hyperparameter from the CLI (used by 04_hparam_search.py):
  python 03_finetune.py --config ../configs/finetune_config.yaml \
      --set model.optim.lr=1e-4 \
      --set freeze.unfreeze_last_n_encoder_layers=3 \
      --set model.train_ds.batch_size=4
"""
import argparse
import copy
import sys

from omegaconf import OmegaConf


def apply_overrides(cfg, overrides: list[str]):
    for ov in overrides:
        key, val = ov.split("=", 1)
        try:
            val = OmegaConf.create(f"x: {val}")["x"]  # parse ints/floats/bools/lists
        except Exception:
            pass  # keep as raw string
        OmegaConf.update(cfg, key, val, merge=True)
    return cfg


def freeze_params(model, freeze_cfg):
    """Freeze/unfreeze encoder blocks, keep decoder+joint trainable (default)."""
    if freeze_cfg.get("freeze_encoder", False):
        for p in model.encoder.parameters():
            p.requires_grad = False

        n_unfreeze = int(freeze_cfg.get("unfreeze_last_n_encoder_layers", 0))
        if n_unfreeze > 0:
            layers = list(model.encoder.layers)  # conformer blocks
            for layer in layers[-n_unfreeze:]:
                for p in layer.parameters():
                    p.requires_grad = True

    if freeze_cfg.get("freeze_decoder", False):
        for p in model.decoder.parameters():
            p.requires_grad = False

    if freeze_cfg.get("freeze_joint", False) and hasattr(model, "joint"):
        for p in model.joint.parameters():
            p.requires_grad = False

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"Trainable params: {trainable:,} / {total:,} "
          f"({100*trainable/total:.1f}%)")
    return model


def build_trainer(cfg):
    import pytorch_lightning as pl
    from pytorch_lightning.callbacks import EarlyStopping

    callbacks = []
    es_cfg = cfg.get("early_stopping", None)
    if es_cfg:
        callbacks.append(EarlyStopping(
            monitor=es_cfg.monitor, patience=es_cfg.patience, mode=es_cfg.mode,
        ))

    trainer = pl.Trainer(
        devices=cfg.trainer.devices,
        accelerator=cfg.trainer.accelerator,
        max_epochs=cfg.trainer.max_epochs,
        precision=cfg.trainer.precision,
        gradient_clip_val=cfg.trainer.gradient_clip_val,
        accumulate_grad_batches=cfg.trainer.accumulate_grad_batches,
        val_check_interval=cfg.trainer.val_check_interval,
        log_every_n_steps=cfg.trainer.log_every_n_steps,
        callbacks=callbacks,
    )
    return trainer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--pretrained_name", default="nvidia/nemotron-3.5-asr-streaming-0.6b")
    ap.add_argument("--set", dest="overrides", action="append", default=[],
                     help="dotted.key=value override, repeatable")
    ap.add_argument("--resume_from", default=None,
                     help="optional .nemo/.ckpt to resume/continue from instead of "
                          "the base pretrained model")
    args = ap.parse_args()

    import nemo.collections.asr as nemo_asr
    from nemo.utils.exp_manager import exp_manager

    cfg = OmegaConf.load(args.config)
    cfg = apply_overrides(cfg, args.overrides)
    print(OmegaConf.to_yaml(cfg))

    # ── load pretrained model ────────────────────────────────────────────
    if args.resume_from:
        model = nemo_asr.models.ASRModel.restore_from(args.resume_from)
    else:
        model = nemo_asr.models.ASRModel.from_pretrained(args.pretrained_name)

    # preserve the exact streaming context size the production server uses,
    # so what we optimize for = what gets deployed
    model.encoder.set_default_att_context_size(list(cfg.model.encoder.att_context_size))

    # apply datasets / spec augment / optimizer config from our yaml
    model.setup_training_data(cfg.model.train_ds)
    model.setup_multiple_validation_data(cfg.model.validation_ds)
    if "spec_augment" in cfg.model:
        model.spec_augmentation = model.from_config_dict(cfg.model.spec_augment)
    model.setup_optimization(cfg.model.optim)

    model = freeze_params(model, cfg.freeze)

    trainer = build_trainer(cfg)
    model.set_trainer(trainer)

    exp_manager(trainer, cfg.exp_manager)

    trainer.fit(model)

    best_ckpt = trainer.checkpoint_callback.best_model_path if trainer.checkpoint_callback else None
    best_score = getattr(trainer.checkpoint_callback, "best_model_score", None)
    # best_model_score is a torch.Tensor from PyTorch Lightning; cast to a
    # plain python float so 04_hparam_search.py's line-parsing (which expects
    # "Best val_wer: <float>") doesn't choke on a "tensor(0.23...)" repr.
    if best_score is not None:
        try:
            best_score = float(best_score)
        except (TypeError, ValueError):
            best_score = None

    print(f"\nDone. Best checkpoint: {best_ckpt}")
    print(f"Best val_wer: {best_score if best_score is not None else 'n/a'}")

    # also always dump a final .nemo for easy drop-in to app/config.py's
    # LOCAL_MODEL_MAP
    final_path = f"{cfg.exp_manager.exp_dir}/{cfg.exp_manager.name}_final.nemo"
    model.save_to(final_path)
    print(f"Saved final .nemo -> {final_path}")
    return best_ckpt


if __name__ == "__main__":
    main()
