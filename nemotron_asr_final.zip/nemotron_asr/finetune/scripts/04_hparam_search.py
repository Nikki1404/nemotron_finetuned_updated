#!/usr/bin/env python3
"""
04_hparam_search.py

Optuna search over the hyperparameters that actually matter for a
tiny-data fine-tune: learning rate, how much of the encoder to unfreeze,
batch/accumulation, weight decay, and SpecAugment strength. Each trial
runs a SHORT fine-tune (few epochs) and is scored on held-out val WER;
the winning config is what you then run full-length with 03_finetune.py.

With a dataset this small, don't over-search: 12-20 trials at ~6-8 epochs
each is plenty and keeps total GPU time reasonable. Going wider just risks
picking a config that overfit to the small val set by luck.

Usage:
  python 04_hparam_search.py --config ../configs/finetune_config.yaml \
      --n_trials 15 --short_epochs 6

Output:
  ../checkpoints/hparam_search/study.db          (resumable Optuna study)
  ../checkpoints/hparam_search/best_config.yaml  (winning config, ready
      to hand to 03_finetune.py for the full run)
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

import optuna
from omegaconf import OmegaConf


def objective_factory(base_config_path: str, short_epochs: int, work_dir: Path):
    def objective(trial: optuna.Trial) -> float:
        lr = trial.suggest_float("lr", 1e-6, 5e-4, log=True)
        unfreeze_n = trial.suggest_int("unfreeze_last_n_encoder_layers", 0, 4)
        weight_decay = trial.suggest_float("weight_decay", 1e-4, 1e-2, log=True)
        batch_size = trial.suggest_categorical("batch_size", [4, 8, 16])
        accum = trial.suggest_categorical("accumulate_grad_batches", [1, 2, 4])
        time_masks = trial.suggest_int("time_masks", 2, 8)
        freq_masks = trial.suggest_int("freq_masks", 1, 3)

        trial_dir = work_dir / f"trial_{trial.number}"
        trial_dir.mkdir(parents=True, exist_ok=True)

        overrides = [
            f"model.optim.lr={lr}",
            f"model.optim.weight_decay={weight_decay}",
            f"model.train_ds.batch_size={batch_size}",
            f"trainer.accumulate_grad_batches={accum}",
            f"trainer.max_epochs={short_epochs}",
            f"model.spec_augment.time_masks={time_masks}",
            f"model.spec_augment.freq_masks={freq_masks}",
            f"freeze.unfreeze_last_n_encoder_layers={unfreeze_n}",
            f"exp_manager.exp_dir={trial_dir}",
            f"exp_manager.name=trial_{trial.number}",
            "early_stopping.patience=3",
        ]

        cmd = [sys.executable, "03_finetune.py", "--config", base_config_path]
        for ov in overrides:
            cmd += ["--set", ov]

        result_path = trial_dir / "result.json"
        cmd += ["--set", f"exp_manager.exp_dir={trial_dir}"]

        print(f"\n=== Trial {trial.number}: lr={lr:.2e} unfreeze={unfreeze_n} "
              f"bs={batch_size} accum={accum} wd={weight_decay:.2e} "
              f"masks(t={time_masks},f={freq_masks}) ===")

        proc = subprocess.run(cmd, capture_output=True, text=True)
        log_path = trial_dir / "train_log.txt"
        log_path.write_text(proc.stdout + "\n\nSTDERR:\n" + proc.stderr)

        if proc.returncode != 0:
            print(f"Trial {trial.number} FAILED, see {log_path}")
            raise optuna.TrialPruned()

        # 03_finetune.py prints "Best val_wer: <value>" — parse it back out.
        # (Kept simple/robust rather than plumbing a return-value IPC channel.)
        wer = None
        for line in proc.stdout.splitlines():
            if line.strip().startswith("Best val_wer:"):
                try:
                    wer = float(line.split(":", 1)[1].strip())
                except ValueError:
                    pass
        if wer is None:
            print(f"Could not parse val_wer for trial {trial.number}, see {log_path}")
            raise optuna.TrialPruned()

        return wer

    return objective


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--n_trials", type=int, default=15)
    ap.add_argument("--short_epochs", type=int, default=6,
                     help="Epochs per trial — short on purpose, this is a search not a final run")
    ap.add_argument("--work_dir", default="../checkpoints/hparam_search")
    ap.add_argument("--study_name", default="nemotron_inspira_search")
    args = ap.parse_args()

    work_dir = Path(args.work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    study = optuna.create_study(
        study_name=args.study_name,
        storage=f"sqlite:///{work_dir}/study.db",
        direction="minimize",
        load_if_exists=True,
        pruner=optuna.pruners.MedianPruner(n_warmup_steps=2),
    )

    study.optimize(
        objective_factory(args.config, args.short_epochs, work_dir),
        n_trials=args.n_trials,
    )

    print("\n=== Best trial ===")
    print(f"val_wer = {study.best_value:.4f}")
    print(json.dumps(study.best_params, indent=2))

    # write out a ready-to-use full config with the winning hyperparameters
    cfg = OmegaConf.load(args.config)
    bp = study.best_params
    cfg.model.optim.lr = bp["lr"]
    cfg.model.optim.weight_decay = bp["weight_decay"]
    cfg.model.train_ds.batch_size = bp["batch_size"]
    cfg.trainer.accumulate_grad_batches = bp["accumulate_grad_batches"]
    cfg.model.spec_augment.time_masks = bp["time_masks"]
    cfg.model.spec_augment.freq_masks = bp["freq_masks"]
    cfg.freeze.unfreeze_last_n_encoder_layers = bp["unfreeze_last_n_encoder_layers"]
    cfg.trainer.max_epochs = 30  # back to full length for the real run

    best_path = work_dir / "best_config.yaml"
    OmegaConf.save(cfg, best_path)
    print(f"\nWrote winning config -> {best_path}")
    print(f"Run the full fine-tune with:\n"
          f"  python 03_finetune.py --config {best_path}")


if __name__ == "__main__":
    main()
