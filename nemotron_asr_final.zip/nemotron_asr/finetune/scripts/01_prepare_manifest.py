#!/usr/bin/env python3
"""
01_prepare_manifest.py

Your raw data is 7 FULL-CALL recordings, each mapped to ONE full-call
transcript (no per-utterance timestamps). A 0.6B streaming conformer is
trained on utterance-level clips (a few seconds each), so step 1 is turning
each long call into many short, correctly-labeled clips.

Two segmentation strategies are supported:

  --align nfa   (RECOMMENDED, default if NFA is installed)
      Uses NVIDIA NeMo Forced Aligner (NFA) to force-align the full
      transcript against the full audio and cut word/segment-accurate
      clips. This gives you real per-clip ground truth text.
      Install: git clone https://github.com/NVIDIA/NeMo, then
      `python <NeMo>/tools/nemo_forced_aligner/align.py` is what this
      script shells out to.

  --align vad   (fallback, no extra install beyond webrtcvad)
      Splits audio on silence only (energy/webrtcvad based), then
      distributes the transcript across segments proportionally to
      segment duration (word count weighted). This is APPROXIMATE —
      text boundaries won't be perfectly accurate — but it still gives
      usable utterance-length clips for fine-tuning when you don't want
      to install NFA. Prefer `nfa` whenever possible.

Output:
  manifests/train_manifest.json
  manifests/val_manifest.json
  (NeMo manifest format: one JSON object per line with
   audio_filepath, text, duration)

Usage:
  python 01_prepare_manifest.py \
      --wav_dir /path/to/raw_wavs \
      --csv /path/to/inspira_transcripts.csv \
      --out_dir ../manifests \
      --align nfa \
      --val_ratio 0.15
"""
import argparse
import csv
import json
import os
import random
import re
import shutil
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np


# ── filename <-> use_case fuzzy matching ─────────────────────────────────────
def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def match_wav_to_csv(wav_dir: Path, rows: list[dict]) -> dict[str, dict]:
    wavs = sorted(wav_dir.glob("*.wav"))
    matched = {}
    for row in rows:
        key = norm(row["use_case"])
        best = None
        for w in wavs:
            wk = norm(w.stem)
            if wk == key or wk in key or key in wk:
                best = w
                break
        if best is None:
            # last resort: token overlap
            tokens = set(re.findall(r"[a-z0-9]+", row["use_case"].lower()))
            best_score, best_w = 0, None
            for w in wavs:
                wtok = set(re.findall(r"[a-z0-9]+", w.stem.lower()))
                score = len(tokens & wtok)
                if score > best_score:
                    best_score, best_w = score, w
            best = best_w
        if best is not None:
            matched[str(best)] = row
        else:
            print(f"WARNING: no wav match found for use_case='{row['use_case']}'", file=sys.stderr)
    return matched


# ── audio helpers ─────────────────────────────────────────────────────────
def load_wav_mono16k(path: Path, target_sr: int = 16000) -> tuple[np.ndarray, int]:
    """Load any wav (any sr/channels) -> mono float32 @ target_sr using ffmpeg."""
    import soundfile as sf
    import resampy

    data, sr = sf.read(str(path), always_2d=False)
    if data.ndim > 1:
        data = data.mean(axis=1)
    data = data.astype(np.float32)
    if sr != target_sr:
        data = resampy.resample(data, sr, target_sr)
        sr = target_sr
    return data, sr


def write_wav(path: Path, audio: np.ndarray, sr: int):
    import soundfile as sf
    sf.write(str(path), audio, sr, subtype="PCM_16")


# ── VAD-based fallback segmentation ─────────────────────────────────────────
def vad_segments(audio: np.ndarray, sr: int, frame_ms: int = 30,
                  min_seg_sec: float = 2.0, max_seg_sec: float = 15.0,
                  min_silence_ms: int = 400) -> list[tuple[float, float]]:
    """Energy-based VAD -> list of (start_sec, end_sec) speech segments,
    merged so each segment lands in [min_seg_sec, max_seg_sec] where possible."""
    frame_len = int(sr * frame_ms / 1000)
    n_frames = len(audio) // frame_len
    energies = np.array([
        np.sqrt(np.mean(audio[i * frame_len:(i + 1) * frame_len] ** 2) + 1e-12)
        for i in range(n_frames)
    ])
    thresh = max(energies.mean() * 0.35, 1e-4)
    is_speech = energies > thresh

    # find raw speech runs
    runs = []
    start = None
    silence_run = 0
    min_silence_frames = int(min_silence_ms / frame_ms)
    for i, sp in enumerate(is_speech):
        if sp:
            if start is None:
                start = i
            silence_run = 0
        else:
            if start is not None:
                silence_run += 1
                if silence_run >= min_silence_frames:
                    runs.append((start, i - silence_run + 1))
                    start = None
                    silence_run = 0
    if start is not None:
        runs.append((start, n_frames))

    # merge short runs together up to max_seg_sec, split long runs at max_seg_sec
    segs = []
    cur_start = None
    cur_end = None
    for (s, e) in runs:
        s_sec, e_sec = s * frame_ms / 1000, e * frame_ms / 1000
        if cur_start is None:
            cur_start, cur_end = s_sec, e_sec
            continue
        if (e_sec - cur_start) <= max_seg_sec:
            cur_end = e_sec
        else:
            if cur_end - cur_start >= min_seg_sec:
                segs.append((cur_start, cur_end))
            cur_start, cur_end = s_sec, e_sec
    if cur_start is not None and cur_end - cur_start >= min_seg_sec:
        segs.append((cur_start, cur_end))

    # hard-split any segment still longer than max_seg_sec
    final = []
    for (s, e) in segs:
        dur = e - s
        if dur <= max_seg_sec:
            final.append((s, e))
        else:
            n_chunks = int(np.ceil(dur / max_seg_sec))
            step = dur / n_chunks
            for k in range(n_chunks):
                final.append((s + k * step, s + (k + 1) * step))
    return final


def split_text_proportionally(text: str, seg_durations: list[float]) -> list[str]:
    """Approximate: distribute words across segments weighted by duration."""
    words = text.split()
    total_dur = sum(seg_durations) or 1.0
    out = []
    idx = 0
    for i, d in enumerate(seg_durations):
        if i == len(seg_durations) - 1:
            chunk = words[idx:]
        else:
            n_words = max(1, round(len(words) * (d / total_dur)))
            chunk = words[idx:idx + n_words]
            idx += n_words
        out.append(" ".join(chunk))
    return out


# ── NFA-based segmentation ───────────────────────────────────────────────────
def nfa_segments(wav_path: Path, text: str, work_dir: Path, nfa_script: str,
                  python_bin: str = "python") -> list[tuple[float, float, str]]:
    """
    Shells out to NeMo Forced Aligner. Returns list of (start_sec, end_sec, text)
    at the segment ("sentence-ish") granularity NFA emits, which we treat as
    training clips.
    NFA outputs CTM files with word-level timings; we group words into clips
    of ~4-12 words / <= 15s using pause gaps.
    """
    call_dir = work_dir / wav_path.stem
    call_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = call_dir / "nfa_input_manifest.json"
    with open(manifest_path, "w") as f:
        f.write(json.dumps({"audio_filepath": str(wav_path), "text": text}) + "\n")

    cmd = [
        python_bin, nfa_script,
        f"pretrained_name=stt_en_fastconformer_hybrid_large_pc",
        f"manifest_filepath={manifest_path}",
        f"output_dir={call_dir}",
        "additional_segment_grouping_separator=|",
    ]
    print("Running NFA:", " ".join(cmd))
    subprocess.run(cmd, check=True)

    ctm_dir = call_dir / "ctm" / "words"
    ctm_files = list(ctm_dir.glob("*.ctm")) if ctm_dir.exists() else []
    if not ctm_files:
        raise RuntimeError(f"NFA produced no CTM output for {wav_path}")

    words = []
    with open(ctm_files[0]) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 5:
                continue
            start, dur, word = float(parts[2]), float(parts[3]), parts[4]
            words.append((start, start + dur, word))

    # group words into clips: break on pause > 0.5s or > 15 words or > 15s
    clips, cur = [], []
    for (ws, we, w) in words:
        if cur and (ws - cur[-1][1] > 0.5 or len(cur) >= 15 or (we - cur[0][0]) > 15.0):
            clips.append(cur)
            cur = []
        cur.append((ws, we, w))
    if cur:
        clips.append(cur)

    out = []
    for c in clips:
        s, e = c[0][0], c[-1][1]
        txt = " ".join(w for _, _, w in c)
        if e - s >= 0.5:
            out.append((s, e, txt))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wav_dir", required=True)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out_dir", default="../manifests")
    ap.add_argument("--clips_dir", default="../data/clips")
    ap.add_argument("--align", choices=["nfa", "vad"], default="vad")
    ap.add_argument("--nfa_script", default="",
                     help="Path to NeMo/tools/nemo_forced_aligner/align.py (required if --align nfa)")
    ap.add_argument("--val_ratio", type=float, default=0.15,
                     help="Held out per-call, not just per-clip, to avoid leakage")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    wav_dir = Path(args.wav_dir)
    out_dir = Path(args.out_dir)
    clips_dir = Path(args.clips_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    clips_dir.mkdir(parents=True, exist_ok=True)

    with open(args.csv, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    matched = match_wav_to_csv(wav_dir, rows)
    print(f"Matched {len(matched)}/{len(rows)} CSV rows to wav files.")

    all_entries = []  # (wav_stem, clip_path, text, duration)
    call_ids = []

    for wav_path_str, row in matched.items():
        wav_path = Path(wav_path_str)
        text_full = re.sub(r"\s+", " ", row["transcript"]).strip()
        print(f"\nProcessing {wav_path.name} ({len(text_full.split())} words)")

        audio, sr = load_wav_mono16k(wav_path, target_sr=16000)
        call_id = wav_path.stem
        call_ids.append(call_id)

        if args.align == "nfa":
            if not args.nfa_script:
                raise SystemExit("--nfa_script is required when --align nfa")
            segs = nfa_segments(wav_path, text_full, out_dir / "_nfa_work", args.nfa_script)
            triplets = [(s, e, t) for (s, e, t) in segs]
        else:
            durations = None
            bounds = vad_segments(audio, sr)
            if not bounds:
                print(f"  no speech detected via VAD, skipping {wav_path.name}")
                continue
            durations = [e - s for (s, e) in bounds]
            texts = split_text_proportionally(text_full, durations)
            triplets = [(s, e, t) for (s, e), t in zip(bounds, texts)]

        for i, (s, e, t) in enumerate(triplets):
            t = t.strip()
            if not t or (e - s) < 0.4:
                continue
            clip = audio[int(s * sr):int(e * sr)]
            clip_name = f"{call_id}_{i:03d}.wav"
            clip_path = clips_dir / clip_name
            write_wav(clip_path, clip, sr)
            all_entries.append({
                "audio_filepath": str(clip_path.resolve()),
                "text": t.lower(),
                "duration": round(len(clip) / sr, 3),
                "call_id": call_id,
            })
        print(f"  -> {len(triplets)} clips")

    if not all_entries:
        raise SystemExit("No clips produced. Check matching / VAD thresholds.")

    # split by CALL, not by clip, so val set is unseen dialog (no leakage)
    random.shuffle(call_ids)
    n_val_calls = max(1, round(len(call_ids) * args.val_ratio))
    val_calls = set(call_ids[:n_val_calls])

    train_entries = [e for e in all_entries if e["call_id"] not in val_calls]
    val_entries = [e for e in all_entries if e["call_id"] in val_calls]

    def dump(entries, path):
        with open(path, "w") as f:
            for e in entries:
                e = {k: v for k, v in e.items() if k != "call_id"}
                f.write(json.dumps(e) + "\n")

    dump(train_entries, out_dir / "train_manifest.json")
    dump(val_entries, out_dir / "val_manifest.json")

    tr_dur = sum(e["duration"] for e in train_entries)
    va_dur = sum(e["duration"] for e in val_entries)
    print(f"\nTrain: {len(train_entries)} clips, {tr_dur/60:.1f} min "
          f"(calls: {sorted(set(call_ids) - val_calls)})")
    print(f"Val:   {len(val_entries)} clips, {va_dur/60:.1f} min "
          f"(calls: {sorted(val_calls)})")
    print(f"\nWrote {out_dir/'train_manifest.json'} and {out_dir/'val_manifest.json'}")
    if args.align == "vad":
        print("\nNOTE: --align vad gives APPROXIMATE text boundaries per clip.\n"
              "For real accuracy gains, install NeMo Forced Aligner and rerun with "
              "--align nfa — it aligns your exact transcript to exact audio timing.")


if __name__ == "__main__":
    main()
