#!/usr/bin/env bash
# run_pipeline.sh — end-to-end: prep -> augment -> hparam search -> finetune -> evaluate -> benchmark
# Run this ON YOUR GPU BOX, from inside <project_root>/finetune/
set -euo pipefail

WAV_DIR="${1:-/path/to/raw_wavs}"
CSV="${2:-/path/to/inspira_transcripts.csv}"
NOISE_DIR="${3:-}"   # optional: folder of real noise .wav clips

cd "$(dirname "$0")/scripts"

echo "=== [1/6] Segmenting long calls into training clips ==="
python 01_prepare_manifest.py \
  --wav_dir "$WAV_DIR" \
  --csv "$CSV" \
  --out_dir ../manifests \
  --align vad \
  --val_ratio 0.15

echo "=== [2/6] Augmenting train set (telephony + noise + reverb + speed/gain) ==="
AUG_ARGS=(--manifest ../manifests/train_manifest.json \
          --out_manifest ../manifests/train_manifest_aug.json \
          --out_dir ../data/clips_aug \
          --variants_per_clip 5)
if [[ -n "$NOISE_DIR" ]]; then
  AUG_ARGS+=(--noise_dir "$NOISE_DIR")
fi
python 02_augment_data.py "${AUG_ARGS[@]}"

echo "=== [3/6] Hyperparameter search (short runs, Optuna) ==="
python 04_hparam_search.py \
  --config ../configs/finetune_config.yaml \
  --n_trials 15 \
  --short_epochs 6

echo "=== [4/6] Full fine-tune with winning hyperparameters ==="
python 03_finetune.py --config ../checkpoints/hparam_search/best_config.yaml

echo "=== [5/6] Evaluating WER/CER: baseline vs finetuned, clean/telephony/noisy ==="
python 05_evaluate.py \
  --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
  --val_manifest ../manifests/val_manifest.json

echo "=== [6/6] Benchmarking streaming latency: baseline vs finetuned ==="
python 06_benchmark_latency.py \
  --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
  --val_manifest ../manifests/val_manifest.json \
  --context_right 1

echo ""
echo "Done. Results:"
echo "  ../checkpoints/eval_results.json"
echo "  ../checkpoints/latency_results.json"
echo "  ../checkpoints/nemotron35_inspira_finetune_final.nemo"
echo ""
echo "Deploy it:"
echo "  export FINETUNED_MODEL_PATH=\$(pwd)/../checkpoints/nemotron35_inspira_finetune_final.nemo"
echo "  uvicorn app.main:app --host 0.0.0.0 --port 8000   # run from project root"
