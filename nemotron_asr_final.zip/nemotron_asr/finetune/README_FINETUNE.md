# Fine-tuning nemotron-3.5-asr-streaming-0.6b on your call-center data

Built against your `nemotron_asr` project (FastAPI + NeMo streaming server,
`nvidia/nemotron-3.5-asr-streaming-0.6b`) and your uploaded data:
**7 full-call recordings (~10.6 min total), 24kHz/48kHz mono, each mapped
to one full-call transcript** in `inspira_transcripts.csv`.

## Reality check on the data (read this first)

10.6 minutes of audio is *very* small for fine-tuning a 0.6B-parameter ASR
model. Two things make this workable instead of a guaranteed overfit:

1. **Segment first.** Each call becomes many short clips (a few seconds
   each) via `01_prepare_manifest.py`, so you're training on dozens of
   utterance-length examples per call, not 7 giant ones.
2. **Freeze most of the model.** `finetune_config.yaml` freezes the
   encoder and only unfreezes the last 0-4 conformer blocks + decoder/joint
   (search picks the number). You're doing targeted domain adaptation —
   your product names, "Inspira Financial", ticket-number phrasing, member
   ID patterns — not re-teaching English from scratch.

Set expectations accordingly: this will make the model noticeably better
on **your specific vocabulary and call patterns**, and — via the
augmentation in step 2 — meaningfully more robust to telephony/noise
*within the domain you trained on*. It will not turn 10 minutes of audio
into a general-purpose noise-robust model on its own. If you can add more
real call recordings later (even 1-2 hours makes a big difference), rerun
the same pipeline — everything here scales up as-is.

## Pipeline

```
scripts/
  01_prepare_manifest.py    long calls -> segmented utterance clips + NeMo manifests
  02_augment_data.py        telephony sim + noise + reverb + speed/gain -> augmented train manifest
  03_finetune.py             loads pretrained model, freezes/unfreezes, trains
  04_hparam_search.py        Optuna search over lr/freeze-depth/batch/SpecAugment
  05_evaluate.py              WER + CER, baseline vs finetuned, clean/telephony/noisy
  06_benchmark_latency.py    TTFT / per-chunk latency / RTF using YOUR real StreamingSession code
configs/finetune_config.yaml   all hyperparameters, documented inline
run_pipeline.sh                 runs all of the above end to end
```

### 1. Environment (on your GPU box)

```bash
cd /path/to/project        # the project root (contains app/, requirements.txt)
pip install -r requirements.txt
pip install -r finetune/requirements_finetune.txt
```

### 2. Segment your calls into training clips

```bash
cd scripts
python 01_prepare_manifest.py \
  --wav_dir /path/to/raw_wavs \
  --csv /path/to/inspira_transcripts.csv \
  --out_dir ../manifests \
  --align vad \
  --val_ratio 0.15
```

`--align vad` (default here) splits on silence and distributes the
transcript proportionally — approximate, but requires nothing extra. Val
split is **by call**, not by clip, so you're validating on entirely unseen
dialogs, not near-duplicate neighbors of training clips.

**For real accuracy gains, use forced alignment instead** so clip
boundaries exactly match transcript boundaries:

```bash
git clone https://github.com/NVIDIA/NeMo
pip install -r NeMo/tools/nemo_forced_aligner/requirements.txt
python 01_prepare_manifest.py ... --align nfa \
  --nfa_script /path/to/NeMo/tools/nemo_forced_aligner/align.py
```

With only 7 calls, alignment accuracy matters a lot — every mislabeled
clip is a meaningful fraction of your training set. NFA is worth the extra
install.

### 3. Augment for noise/telephony robustness

```bash
python 02_augment_data.py \
  --manifest ../manifests/train_manifest.json \
  --out_manifest ../manifests/train_manifest_aug.json \
  --out_dir ../data/clips_aug \
  --variants_per_clip 5 \
  --noise_dir /path/to/real/noise/clips   # optional but recommended
```

Generates telephony (8kHz band-limit + mu-law codec sim), additive noise
(0-20dB SNR), synthetic reverb, and speed/gain variants per clip. If you
can supply real call-center floor noise / office / street recordings via
`--noise_dir`, do — synthetic noise is a reasonable fallback but real
noise generalizes better. `finetune_config.yaml` layers *additional*
SpecAugment + noise on top of this live during training, so effectively
every clip is seen in a different augmented form each epoch.

Validation/test data is **never** augmented here — you want to know how
the model does on realistic held-out audio, and you build clean/noisy/
telephony *eval* variants separately in step 5.

### 4. Hyperparameter search

```bash
python 04_hparam_search.py --config ../configs/finetune_config.yaml \
  --n_trials 15 --short_epochs 6
```

Searches: learning rate, weight decay, batch size, grad accumulation,
SpecAugment mask counts, and — most importantly for this dataset size —
**how many encoder layers to unfreeze** (0-4). Each trial is a short run
scored on val WER; don't push `n_trials` much higher than ~15-20 with this
little data, or you're just tuning to sampling noise in a tiny val set.
Writes `../checkpoints/hparam_search/best_config.yaml`.

### 5. Full fine-tune

```bash
python 03_finetune.py --config ../checkpoints/hparam_search/best_config.yaml
```

Early stopping on val WER (patience=6) since tiny data overfits fast.
Produces `../checkpoints/nemotron35_inspira_finetune_final.nemo`.

### 6. Evaluate accuracy (WER/CER, three conditions)

```bash
python 05_evaluate.py \
  --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
  --val_manifest ../manifests/val_manifest.json
```

Reports baseline-vs-finetuned WER **and** CER for clean / telephony /
noisy versions of your held-out val clips, both offline (`model.transcribe`)
and streaming (via `StreamingSession`, the actual production code path) —
these numbers can and do diverge, and streaming is what your users
experience.

### 7. Benchmark latency

```bash
python 06_benchmark_latency.py \
  --finetuned_model ../checkpoints/nemotron35_inspira_finetune_final.nemo \
  --val_manifest ../manifests/val_manifest.json \
  --context_right 1
```

TTFT, per-chunk latency (mean/p50/p95), finalize latency, and RTF —
measured through your real `NemotronStreamingASR`/`StreamingSession`
classes. `--context_right` must match your server's `CONTEXT_RIGHT` env
var for the numbers to mean anything for your deployment.

**Important:** fine-tuning as configured here does not change latency —
`finetune_config.yaml` pins `att_context_size: [70, 1]` to match your
current `CONTEXT_RIGHT=1` default, and no architecture changes are made.
Latency should come out ~identical to baseline; this script exists to
*confirm* that (catch regressions) rather than to find latency wins.
If you separately want to trade accuracy for even lower latency, that's a
`CONTEXT_RIGHT` server-config change, not a fine-tuning change — don't
conflate the two when reading eval numbers.

### 8. Deploy

`app/config.py` now has a `FINETUNED_MODEL_PATH` override built in — no
code edits needed:

```bash
export FINETUNED_MODEL_PATH=/srv/nemotron35_inspira_finetune_final.nemo
uvicorn app.main:app --host 0.0.0.0 --port 8000   # run from project root
```

This overrides the `nemotron` backend's model for both single-engine
startup (`load_config()`) and the multi-engine preload path in
`app/main.py`. If the path doesn't exist, the server logs a warning and
falls back to the base pretrained model instead of failing to start. To
apply it to a different backend key (if you've split en/es engines per
the multi-language section below), set `FINETUNED_MODEL_BACKEND` too.

## Run everything at once

```bash
cd finetune
./run_pipeline.sh /path/to/raw_wavs /path/to/inspira_transcripts.csv [/path/to/noise_dir]
```

## What's NOT included (and why)

- **No GPU training was actually run** — this sandbox has no GPU and no
  access to huggingface.co/NGC to pull the pretrained weights, so every
  script here is written and syntax-checked but not execution-tested end
  to end. Run `run_pipeline.sh` on your box and watch the logs; if a NeMo
  API call name has drifted between NeMo versions, that's the most likely
  fix point (`setup_training_data` / `setup_multiple_validation_data` /
  `conformer_stream_step` signatures do shift between releases — pin your
  `nemo_toolkit` version to whatever the model card for
  `nvidia/nemotron-3.5-asr-streaming-0.6b` specifies).
- **No new public dataset mixed in** — per your choice, this uses only
  your 7 recordings. If WER/robustness after a full run still isn't where
  you need it, the highest-leverage next step is more real audio (even a
  few hours), not more hyperparameter search.
