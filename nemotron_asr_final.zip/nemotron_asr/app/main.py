import asyncio
import json
import logging
import sys

import numpy as np
import resampy
from fastapi import FastAPI, WebSocket

from app.config import load_config, Config, MODEL_MAP, resolve_model_name
from app.factory import build_engine
from app.streaming_session import StreamingSession
from app.asr_engines.base import ASREngine


# ── Global config & logging ──────────────────────────────────────────────────
cfg = load_config()

logging.basicConfig(
    level=cfg.log_level,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("asr_server")

app = FastAPI(title="Nemotron 3.5 ASR Server", version="1.0.0")

# ── Engine cache (backend → engine instance) ─────────────────────────────────
ENGINE_CACHE: dict[str, ASREngine] = {}


# ── Startup: preload all engines ─────────────────────────────────────────────
async def preload_engines():
    log.info("Preloading ASR engines...")

    for backend in MODEL_MAP.keys():
        model_name = resolve_model_name(backend)
        try:
            log.info(f"Initializing engine: {backend} ({model_name})")

            tmp_cfg = Config()
            object.__setattr__(tmp_cfg, "asr_backend", backend)
            object.__setattr__(tmp_cfg, "model_name", model_name)
            object.__setattr__(tmp_cfg, "device", cfg.device)
            object.__setattr__(tmp_cfg, "sample_rate", cfg.sample_rate)
            object.__setattr__(tmp_cfg, "asr_language", cfg.asr_language)

            engine = build_engine(tmp_cfg)
            load_sec = engine.load()

            ENGINE_CACHE[backend] = engine
            log.info(f"✅ Preloaded '{backend}' in {load_sec:.2f}s  language={cfg.asr_language}")

        except Exception:
            log.exception(f"Failed to preload '{backend}'")

    log.info(f"All engines preloaded. Available: {list(ENGINE_CACHE.keys())}")


@app.on_event("startup")
async def startup_event():
    log.info("Server startup initiated")
    await preload_engines()


def get_engine(backend: str) -> ASREngine:
    if backend not in ENGINE_CACHE:
        raise ValueError(f"Engine '{backend}' not loaded. Available: {list(ENGINE_CACHE.keys())}")
    return ENGINE_CACHE[backend]


# ── Health check ─────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {
        "status": "ok",
        "engines": list(ENGINE_CACHE.keys()),
        "device": cfg.device,
        "default_language": cfg.asr_language,
    }


# ── WebSocket ASR endpoint ────────────────────────────────────────────────────
@app.websocket("/asr/realtime-custom-vad")
async def ws_asr(ws: WebSocket):
    """
    WebSocket endpoint for real-time streaming ASR.

    Client sends init JSON first:
    {
        "backend":     "nemotron",        # required
        "sample_rate": 16000,             # optional, client audio SR
        "language":    "en-US"            # optional: "en-US" | "es-US" | "auto"
    }

    Then client streams raw PCM16 binary frames.

    Server emits JSON events:
    {"type": "partial", "text": "...", "t_start": <ttfb_ms>}
    {"type": "final",   "text": "...", "t_start": <ttfb_ms>}
    """
    log.info(f"WS connection request from {ws.client}")
    await ws.accept()

    # ── Parse init message ────────────────────────────────────────────────
    try:
        raw_init = await ws.receive_text()
        init = json.loads(raw_init)
    except Exception as e:
        log.warning(f"Bad init message: {e}")
        await ws.close(code=4001)
        return

    backend = init.get("backend", "nemotron")
    client_sample_rate = int(init.get("sample_rate", cfg.sample_rate))

    # Per-connection language override
    # Priority: init message > env ASR_LANGUAGE > "auto"
    language = init.get("language", cfg.asr_language)

    if backend not in MODEL_MAP:
        log.warning(f"Invalid backend requested: '{backend}'")
        await ws.send_text(json.dumps({"error": f"Unknown backend '{backend}'"}))
        await ws.close(code=4000)
        return

    try:
        engine = get_engine(backend)
    except ValueError as e:
        log.error(str(e))
        await ws.send_text(json.dumps({"error": str(e)}))
        await ws.close(code=4000)
        return

    # Apply language for this connection
    # NOTE: set_language() is model-level state. For truly concurrent
    # multi-language sessions, run separate engine instances per language.
    engine.set_language(language)

    log.info(
        f"WS connected | backend={backend} language={language} "
        f"client_sr={client_sample_rate} server_sr={cfg.sample_rate} "
        f"client={ws.client}"
    )

    # ── Resample helper ───────────────────────────────────────────────────
    def upsample_if_needed(pcm: bytes) -> bytes:
        if not pcm or client_sample_rate == cfg.sample_rate:
            return pcm
        x = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        y = resampy.resample(x, client_sample_rate, cfg.sample_rate)
        y = np.clip(y, -1.0, 1.0)
        return (y * 32767.0).astype(np.int16).tobytes()

    session = StreamingSession(engine, cfg)

    # ── Main receive loop ─────────────────────────────────────────────────
    try:
        while True:
            msg = await ws.receive()

            if msg["type"] == "websocket.disconnect":
                log.info(f"Client disconnected: {ws.client}")
                break

            data = msg.get("bytes")
            if data is None:
                continue

            data = upsample_if_needed(data)

            # Run heavy ASR work off the event loop thread
            loop = asyncio.get_running_loop()
            events = await loop.run_in_executor(None, session.process_chunk, data)

            for ev_type, text, ttfb in events:
                await ws.send_text(
                    json.dumps({"type": ev_type, "text": text, "t_start": ttfb})
                )

    except Exception:
        log.exception(f"Error during WebSocket session for {ws.client}")
    finally:
        log.info(f"WS session closed for {ws.client}")
