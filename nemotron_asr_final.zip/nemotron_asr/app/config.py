from dataclasses import dataclass, replace
import os


@dataclass(frozen=True)
class Config:
    # ── Core ASR selection ──────────────────────────────────────────────────
    asr_backend: str = os.getenv("ASR_BACKEND", "nemotron")
    model_name: str = os.getenv("MODEL_NAME", "")
    device: str = os.getenv("DEVICE", "cuda")

    # ── Language (new for nemotron-3.5 multilingual) ────────────────────────
    # "auto"  = model detects language from audio
    # "en-US" = English (US)       "en-GB" = English (UK)
    # "es-US" = Spanish (US)       "es-ES" = Spanish (Spain)
    # Full list: en-US, en-GB, es-US, es-ES, fr-FR, fr-CA, de-DE, it-IT,
    #            pt-BR, pt-PT, ru-RU, nl-NL, pl-PL, cs-CZ, ar-AR, hi-IN,
    #            ja-JP, ko-KR, vi-VN, tr-TR, nb-NO, he-IL, da-DK, sv-SE,
    #            bg-BG, fi-FI, hr-HR, sk-SK, uk-UA, zh-CN, el-GR, hu-HU,
    #            ro-RO, et-EE, lt-LT, lv-LV, mt-MT, sl-SI, th-TH, nn-NO
    asr_language: str = os.getenv("ASR_LANGUAGE", "auto")

    # ── Common audio ────────────────────────────────────────────────────────
    sample_rate: int = int(os.getenv("SAMPLE_RATE", "16000"))

    # ── Common VAD ──────────────────────────────────────────────────────────
    vad_frame_ms: int = int(os.getenv("VAD_FRAME_MS", "20"))
    vad_start_margin: float = float(os.getenv("VAD_START_MARGIN", "2.5"))
    vad_min_noise_rms: float = float(os.getenv("VAD_MIN_NOISE_RMS", "0.003"))
    pre_speech_ms: int = int(os.getenv("PRE_SPEECH_MS", "300"))

    # ── Global safety constraint ────────────────────────────────────────────
    max_utt_ms: int = int(os.getenv("MAX_UTT_MS", "30000"))

    log_level: str = os.getenv("LOG_LEVEL", "INFO")


# ── Model map ───────────────────────────────────────────────────────────────
# Single "nemotron" backend covers both en + es via language prompt.
# For concurrent multi-language with isolated engine state, add separate keys:
#   "nemotron-en": "nvidia/nemotron-3.5-asr-streaming-0.6b"
#   "nemotron-es": "nvidia/nemotron-3.5-asr-streaming-0.6b"
MODEL_MAP = {
    "nemotron": "nvidia/nemotron-3.5-asr-streaming-0.6b",
}

# If you pre-download the base model to disk (done in Dockerfile), override to:
#   "nemotron": "/srv/nemotron-3.5-asr-streaming-0.6b.nemo"
# LOCAL_MODEL_MAP = {
#     "nemotron": "/srv/nemotron-3.5-asr-streaming-0.6b.nemo",
# }

# ── Fine-tuned model override ────────────────────────────────────────────────
# Output of finetune/scripts/03_finetune.py (see finetune/README_FINETUNE.md).
# Set this env var to the .nemo path to serve your fine-tuned model instead of
# the stock nvidia/nemotron-3.5-asr-streaming-0.6b, with zero code changes:
#   export FINETUNED_MODEL_PATH=/srv/nemotron35_inspira_finetune_final.nemo
# Applies to the backend named by FINETUNED_MODEL_BACKEND (default "nemotron").
FINETUNED_MODEL_PATH = os.getenv("FINETUNED_MODEL_PATH", "")
FINETUNED_MODEL_BACKEND = os.getenv("FINETUNED_MODEL_BACKEND", "nemotron")


def resolve_model_name(backend: str) -> str:
    """Single source of truth for backend -> model_name, used by both
    load_config() (single-engine env override path) and main.py's
    preload_engines() (loops MODEL_MAP directly) so a fine-tuned model
    swap via FINETUNED_MODEL_PATH is picked up everywhere consistently."""
    if FINETUNED_MODEL_PATH and backend == FINETUNED_MODEL_BACKEND:
        if os.path.exists(FINETUNED_MODEL_PATH):
            return FINETUNED_MODEL_PATH
        print(
            f"WARNING: FINETUNED_MODEL_PATH='{FINETUNED_MODEL_PATH}' does not "
            f"exist, falling back to base model for backend='{backend}'."
        )
    return MODEL_MAP.get(backend, "")


def load_config() -> Config:
    cfg = Config()

    # FINETUNED_MODEL_PATH takes priority even if MODEL_NAME is already set
    # (e.g. Dockerfile hardcodes MODEL_NAME to the base model) — this is the
    # one-env-var swap documented in finetune/README_FINETUNE.md.
    if FINETUNED_MODEL_PATH and cfg.asr_backend == FINETUNED_MODEL_BACKEND:
        if os.path.exists(FINETUNED_MODEL_PATH):
            cfg = replace(cfg, model_name=FINETUNED_MODEL_PATH)
        else:
            print(
                f"WARNING: FINETUNED_MODEL_PATH='{FINETUNED_MODEL_PATH}' does not "
                f"exist, ignoring override."
            )

    if not cfg.model_name:
        cfg = replace(cfg, model_name=resolve_model_name(cfg.asr_backend))

    print(
        f"DEBUG: Startup cfg.model_name='{cfg.model_name}' "
        f"cfg.asr_backend='{cfg.asr_backend}' "
        f"cfg.asr_language='{cfg.asr_language}' "
        f"finetuned={'yes' if cfg.model_name == FINETUNED_MODEL_PATH and FINETUNED_MODEL_PATH else 'no'}"
    )

    return cfg
